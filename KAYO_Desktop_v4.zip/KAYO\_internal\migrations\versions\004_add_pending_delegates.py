"""Add pending_delegates table for self-registration

Revision ID: 004_add_pending_delegates
Revises: 003_add_fund_transfer_payment_columns
Create Date: 2025-12-17
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '004_add_pending_delegates'
down_revision = '003_add_fund_transfer_payment_columns'
branch_labels = None
depends_on = None


def upgrade():
    """Create pending_delegates table for self-registration workflow"""
    op.create_table('pending_delegates',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('registration_token', sa.String(length=64), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('local_church', sa.String(length=100), nullable=False),
        sa.Column('parish', sa.String(length=100), nullable=False),
        sa.Column('archdeaconry', sa.String(length=100), nullable=False),
        sa.Column('phone_number', sa.String(length=15), nullable=True),
        sa.Column('id_number', sa.String(length=20), nullable=True),
        sa.Column('email', sa.String(length=120), nullable=True),
        sa.Column('gender', sa.String(length=10), nullable=False),
        sa.Column('category', sa.String(length=20), nullable=True, default='delegate'),
        sa.Column('event_id', sa.Integer(), nullable=True),
        sa.Column('status', sa.String(length=20), nullable=False, default='pending'),
        sa.Column('submitted_at', sa.DateTime(), nullable=True),
        sa.Column('reviewed_at', sa.DateTime(), nullable=True),
        sa.Column('reviewed_by', sa.Integer(), nullable=True),
        sa.Column('reviewer_notes', sa.Text(), nullable=True),
        sa.Column('rejection_reason', sa.Text(), nullable=True),
        sa.Column('delegate_id', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], ),
        sa.ForeignKeyConstraint(['delegate_id'], ['delegates.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('registration_token')
    )
    
    # Create indexes for common queries
    op.create_index('ix_pending_delegates_status', 'pending_delegates', ['status'])
    op.create_index('ix_pending_delegates_local_church', 'pending_delegates', ['local_church'])
    op.create_index('ix_pending_delegates_archdeaconry', 'pending_delegates', ['archdeaconry'])


def downgrade():
    """Drop pending_delegates table"""
    op.drop_index('ix_pending_delegates_archdeaconry', table_name='pending_delegates')
    op.drop_index('ix_pending_delegates_local_church', table_name='pending_delegates')
    op.drop_index('ix_pending_delegates_status', table_name='pending_delegates')
    op.drop_table('pending_delegates')
