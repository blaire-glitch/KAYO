"""Add payment_confirmed_by column to delegates

Revision ID: 008
Revises: 007
Create Date: 2025-12-27
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers
revision = '008'
down_revision = '007'
branch_labels = None
depends_on = None


def upgrade():
    # Add payment confirmation columns to delegates table
    with op.batch_alter_table('delegates', schema=None) as batch_op:
        batch_op.add_column(sa.Column('payment_confirmed_by', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('payment_confirmed_at', sa.DateTime(), nullable=True))
        batch_op.create_foreign_key('fk_delegate_payment_confirmed_by', 'users', ['payment_confirmed_by'], ['id'])


def downgrade():
    with op.batch_alter_table('delegates', schema=None) as batch_op:
        batch_op.drop_constraint('fk_delegate_payment_confirmed_by', type_='foreignkey')
        batch_op.drop_column('payment_confirmed_at')
        batch_op.drop_column('payment_confirmed_by')
