"""add fund management tables

Revision ID: 002_fund_management
Revises: 001_initial
Create Date: 2024-12-14

"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = '002_fund_management'
down_revision = '001_initial'
branch_labels = None
depends_on = None


def upgrade():
    # Pledges table
    op.create_table('pledges',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('source_type', sa.String(length=50), nullable=False),
        sa.Column('source_name', sa.String(length=100), nullable=False),
        sa.Column('source_phone', sa.String(length=15), nullable=True),
        sa.Column('source_email', sa.String(length=120), nullable=True),
        sa.Column('delegate_id', sa.Integer(), nullable=True),
        sa.Column('amount_pledged', sa.Float(), nullable=False),
        sa.Column('amount_paid', sa.Float(), default=0),
        sa.Column('status', sa.String(length=20), default='pending'),
        sa.Column('event_id', sa.Integer(), nullable=True),
        sa.Column('recorded_by', sa.Integer(), nullable=False),
        sa.Column('local_church', sa.String(length=100), nullable=True),
        sa.Column('parish', sa.String(length=100), nullable=True),
        sa.Column('archdeaconry', sa.String(length=100), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('due_date', sa.Date(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['delegate_id'], ['delegates.id'], ),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.ForeignKeyConstraint(['recorded_by'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Pledge payments table
    op.create_table('pledge_payments',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('pledge_id', sa.Integer(), nullable=False),
        sa.Column('amount', sa.Float(), nullable=False),
        sa.Column('payment_method', sa.String(length=50), nullable=False),
        sa.Column('reference', sa.String(length=100), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('status', sa.String(length=20), default='pending'),
        sa.Column('confirmed_by', sa.Integer(), nullable=True),
        sa.Column('confirmed_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['pledge_id'], ['pledges.id'], ),
        sa.ForeignKeyConstraint(['confirmed_by'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Scheduled payments table
    op.create_table('scheduled_payments',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('source_type', sa.String(length=50), nullable=False),
        sa.Column('source_name', sa.String(length=100), nullable=False),
        sa.Column('source_phone', sa.String(length=15), nullable=True),
        sa.Column('source_email', sa.String(length=120), nullable=True),
        sa.Column('delegate_id', sa.Integer(), nullable=True),
        sa.Column('amount', sa.Float(), nullable=False),
        sa.Column('frequency', sa.String(length=20), nullable=False),
        sa.Column('start_date', sa.Date(), nullable=False),
        sa.Column('end_date', sa.Date(), nullable=True),
        sa.Column('next_payment_date', sa.Date(), nullable=True),
        sa.Column('total_expected', sa.Float(), default=0),
        sa.Column('total_collected', sa.Float(), default=0),
        sa.Column('status', sa.String(length=20), default='active'),
        sa.Column('event_id', sa.Integer(), nullable=True),
        sa.Column('recorded_by', sa.Integer(), nullable=False),
        sa.Column('local_church', sa.String(length=100), nullable=True),
        sa.Column('parish', sa.String(length=100), nullable=True),
        sa.Column('archdeaconry', sa.String(length=100), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['delegate_id'], ['delegates.id'], ),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.ForeignKeyConstraint(['recorded_by'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Scheduled payment installments table
    op.create_table('scheduled_payment_installments',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('scheduled_payment_id', sa.Integer(), nullable=False),
        sa.Column('due_date', sa.Date(), nullable=False),
        sa.Column('amount_due', sa.Float(), nullable=False),
        sa.Column('amount_paid', sa.Float(), default=0),
        sa.Column('payment_method', sa.String(length=50), nullable=True),
        sa.Column('reference', sa.String(length=100), nullable=True),
        sa.Column('status', sa.String(length=20), default='pending'),
        sa.Column('confirmed_by', sa.Integer(), nullable=True),
        sa.Column('confirmed_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('paid_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['scheduled_payment_id'], ['scheduled_payments.id'], ),
        sa.ForeignKeyConstraint(['confirmed_by'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Fund transfers table
    op.create_table('fund_transfers',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('reference_number', sa.String(length=50), nullable=False, unique=True),
        sa.Column('amount', sa.Float(), nullable=False),
        sa.Column('from_user_id', sa.Integer(), nullable=False),
        sa.Column('from_role', sa.String(length=50), nullable=False),
        sa.Column('to_user_id', sa.Integer(), nullable=False),
        sa.Column('to_role', sa.String(length=50), nullable=False),
        sa.Column('transfer_stage', sa.String(length=50), nullable=False),
        sa.Column('status', sa.String(length=20), default='pending'),
        sa.Column('local_church', sa.String(length=100), nullable=True),
        sa.Column('parish', sa.String(length=100), nullable=True),
        sa.Column('archdeaconry', sa.String(length=100), nullable=True),
        sa.Column('event_id', sa.Integer(), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('attachments', sa.Text(), default='[]'),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('submitted_at', sa.DateTime(), nullable=True),
        sa.Column('approved_at', sa.DateTime(), nullable=True),
        sa.Column('completed_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['from_user_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['to_user_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Fund transfer approvals table
    op.create_table('fund_transfer_approvals',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('transfer_id', sa.Integer(), nullable=False),
        sa.Column('approved_by', sa.Integer(), nullable=False),
        sa.Column('action', sa.String(length=20), nullable=False),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['transfer_id'], ['fund_transfers.id'], ),
        sa.ForeignKeyConstraint(['approved_by'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Payment summaries table
    op.create_table('payment_summaries',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('user_role', sa.String(length=50), nullable=False),
        sa.Column('period_start', sa.Date(), nullable=False),
        sa.Column('period_end', sa.Date(), nullable=False),
        sa.Column('total_delegate_payments', sa.Float(), default=0),
        sa.Column('total_pledges_received', sa.Float(), default=0),
        sa.Column('total_scheduled_payments', sa.Float(), default=0),
        sa.Column('total_fundraising', sa.Float(), default=0),
        sa.Column('grand_total', sa.Float(), default=0),
        sa.Column('amount_transferred', sa.Float(), default=0),
        sa.Column('amount_pending', sa.Float(), default=0),
        sa.Column('local_church', sa.String(length=100), nullable=True),
        sa.Column('parish', sa.String(length=100), nullable=True),
        sa.Column('archdeaconry', sa.String(length=100), nullable=True),
        sa.Column('event_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.PrimaryKeyConstraint('id')
    )


def downgrade():
    op.drop_table('payment_summaries')
    op.drop_table('fund_transfer_approvals')
    op.drop_table('fund_transfers')
    op.drop_table('scheduled_payment_installments')
    op.drop_table('scheduled_payments')
    op.drop_table('pledge_payments')
    op.drop_table('pledges')
