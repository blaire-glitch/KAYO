"""Add payment_method and mpesa_reference to fund_transfer

Revision ID: 003
Revises: 002_fund_management
Create Date: 2024-01-15

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '003_add_transfer_payment_method'
down_revision = '002_fund_management'
branch_labels = None
depends_on = None


def upgrade():
    # Add payment_method column with default 'cash'
    op.add_column('fund_transfer', 
        sa.Column('payment_method', sa.String(50), nullable=True, server_default='cash')
    )
    
    # Add mpesa_reference column
    op.add_column('fund_transfer',
        sa.Column('mpesa_reference', sa.String(100), nullable=True)
    )
    
    # Update existing rows to have 'cash' as payment_method
    op.execute("UPDATE fund_transfer SET payment_method = 'cash' WHERE payment_method IS NULL")


def downgrade():
    op.drop_column('fund_transfer', 'mpesa_reference')
    op.drop_column('fund_transfer', 'payment_method')
