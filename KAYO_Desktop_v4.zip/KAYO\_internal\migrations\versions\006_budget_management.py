"""Add budget management tables

Revision ID: 006
Revises: 005
Create Date: 2025-12-25
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers
revision = '006'
down_revision = '005'
branch_labels = None
depends_on = None


def upgrade():
    # Create budgets table
    op.create_table('budgets',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('event_id', sa.Integer(), nullable=True),
        sa.Column('name', sa.String(200), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('total_amount', sa.Float(), default=0.0),
        sa.Column('approved_amount', sa.Float(), default=0.0),
        sa.Column('status', sa.String(50), default='draft'),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.Column('approved_by', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('approved_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.ForeignKeyConstraint(['created_by'], ['users.id'], ),
        sa.ForeignKeyConstraint(['approved_by'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    
    # Create budget_items table
    op.create_table('budget_items',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('budget_id', sa.Integer(), nullable=False),
        sa.Column('category', sa.String(100), nullable=True),
        sa.Column('description', sa.String(500), nullable=False),
        sa.Column('estimated_amount', sa.Float(), default=0.0),
        sa.Column('actual_amount', sa.Float(), default=0.0),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.ForeignKeyConstraint(['budget_id'], ['budgets.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    
    # Create budget_expenditures table
    op.create_table('budget_expenditures',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('budget_item_id', sa.Integer(), nullable=False),
        sa.Column('amount', sa.Float(), nullable=False),
        sa.Column('description', sa.String(500), nullable=True),
        sa.Column('receipt_number', sa.String(100), nullable=True),
        sa.Column('vendor', sa.String(200), nullable=True),
        sa.Column('recorded_by', sa.Integer(), nullable=True),
        sa.Column('recorded_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['budget_item_id'], ['budget_items.id'], ),
        sa.ForeignKeyConstraint(['recorded_by'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )


def downgrade():
    op.drop_table('budget_expenditures')
    op.drop_table('budget_items')
    op.drop_table('budgets')
