"""Add Finance Module Tables

Revision ID: 005
Revises: 004
Create Date: 2024-01-15

This migration creates the finance module tables:
- account_categories: Categories for grouping accounts
- accounts: Chart of accounts
- journal_entries: Double-entry journal entries
- journal_lines: Individual debit/credit lines
- vouchers: Payment and receipt vouchers
- voucher_items: Line items on vouchers
- financial_periods: Fiscal periods for reporting
- budget_lines: Budget allocations

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '005'
down_revision = '004'
branch_labels = None
depends_on = None


def upgrade():
    # Account Categories Table
    op.create_table('account_categories',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('code', sa.String(10), nullable=False, unique=True),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('category_type', sa.String(20), nullable=False),
        sa.Column('parent_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['parent_id'], ['account_categories.id'], ),
    )
    op.create_index('idx_account_categories_type', 'account_categories', ['category_type'])

    # Accounts Table (Chart of Accounts)
    op.create_table('accounts',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('code', sa.String(20), nullable=False, unique=True),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('account_type', sa.String(20), nullable=False),
        sa.Column('category_id', sa.Integer(), nullable=True),
        sa.Column('parent_id', sa.Integer(), nullable=True),
        sa.Column('normal_balance', sa.String(10), nullable=False, default='debit'),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('is_active', sa.Boolean(), default=True),
        sa.Column('is_system', sa.Boolean(), default=False),
        sa.Column('opening_balance', sa.Numeric(15, 2), default=0),
        sa.Column('current_balance', sa.Numeric(15, 2), default=0),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['category_id'], ['account_categories.id'], ),
        sa.ForeignKeyConstraint(['parent_id'], ['accounts.id'], ),
    )
    op.create_index('idx_accounts_code', 'accounts', ['code'])
    op.create_index('idx_accounts_type', 'accounts', ['account_type'])
    op.create_index('idx_accounts_active', 'accounts', ['is_active'])

    # Financial Periods Table
    op.create_table('financial_periods',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('start_date', sa.Date(), nullable=False),
        sa.Column('end_date', sa.Date(), nullable=False),
        sa.Column('is_closed', sa.Boolean(), default=False),
        sa.Column('closed_at', sa.DateTime(), nullable=True),
        sa.Column('closed_by_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['closed_by_id'], ['user.id'], ),
    )

    # Journal Entries Table
    op.create_table('journal_entries',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('entry_number', sa.String(30), nullable=False, unique=True),
        sa.Column('date', sa.Date(), nullable=False),
        sa.Column('description', sa.Text(), nullable=False),
        sa.Column('reference', sa.String(100), nullable=True),
        sa.Column('status', sa.String(20), default='draft'),
        sa.Column('entry_type', sa.String(20), default='standard'),
        sa.Column('period_id', sa.Integer(), nullable=True),
        sa.Column('created_by_id', sa.Integer(), nullable=True),
        sa.Column('posted_by_id', sa.Integer(), nullable=True),
        sa.Column('posted_at', sa.DateTime(), nullable=True),
        sa.Column('voided_by_id', sa.Integer(), nullable=True),
        sa.Column('voided_at', sa.DateTime(), nullable=True),
        sa.Column('void_reason', sa.String(255), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['period_id'], ['financial_periods.id'], ),
        sa.ForeignKeyConstraint(['created_by_id'], ['user.id'], ),
        sa.ForeignKeyConstraint(['posted_by_id'], ['user.id'], ),
        sa.ForeignKeyConstraint(['voided_by_id'], ['user.id'], ),
    )
    op.create_index('idx_journal_entries_number', 'journal_entries', ['entry_number'])
    op.create_index('idx_journal_entries_date', 'journal_entries', ['date'])
    op.create_index('idx_journal_entries_status', 'journal_entries', ['status'])

    # Journal Lines Table
    op.create_table('journal_lines',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('journal_entry_id', sa.Integer(), nullable=False),
        sa.Column('account_id', sa.Integer(), nullable=False),
        sa.Column('debit', sa.Numeric(15, 2), nullable=True),
        sa.Column('credit', sa.Numeric(15, 2), nullable=True),
        sa.Column('description', sa.String(255), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['journal_entry_id'], ['journal_entries.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['account_id'], ['accounts.id'], ),
    )
    op.create_index('idx_journal_lines_entry', 'journal_lines', ['journal_entry_id'])
    op.create_index('idx_journal_lines_account', 'journal_lines', ['account_id'])

    # Vouchers Table
    op.create_table('vouchers',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('voucher_number', sa.String(30), nullable=False, unique=True),
        sa.Column('voucher_type', sa.String(20), nullable=False),
        sa.Column('date', sa.Date(), nullable=False),
        sa.Column('payee', sa.String(200), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('amount', sa.Numeric(15, 2), default=0),
        sa.Column('status', sa.String(20), default='draft'),
        sa.Column('payment_method', sa.String(20), nullable=True),
        sa.Column('payment_reference', sa.String(100), nullable=True),
        sa.Column('bank_account_id', sa.Integer(), nullable=True),
        sa.Column('journal_entry_id', sa.Integer(), nullable=True),
        sa.Column('created_by_id', sa.Integer(), nullable=True),
        sa.Column('approved_by_id', sa.Integer(), nullable=True),
        sa.Column('approved_at', sa.DateTime(), nullable=True),
        sa.Column('paid_by_id', sa.Integer(), nullable=True),
        sa.Column('paid_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['bank_account_id'], ['accounts.id'], ),
        sa.ForeignKeyConstraint(['journal_entry_id'], ['journal_entries.id'], ),
        sa.ForeignKeyConstraint(['created_by_id'], ['user.id'], ),
        sa.ForeignKeyConstraint(['approved_by_id'], ['user.id'], ),
        sa.ForeignKeyConstraint(['paid_by_id'], ['user.id'], ),
    )
    op.create_index('idx_vouchers_number', 'vouchers', ['voucher_number'])
    op.create_index('idx_vouchers_type', 'vouchers', ['voucher_type'])
    op.create_index('idx_vouchers_status', 'vouchers', ['status'])
    op.create_index('idx_vouchers_date', 'vouchers', ['date'])

    # Voucher Items Table
    op.create_table('voucher_items',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('voucher_id', sa.Integer(), nullable=False),
        sa.Column('description', sa.String(255), nullable=False),
        sa.Column('quantity', sa.Numeric(10, 2), default=1),
        sa.Column('unit_price', sa.Numeric(15, 2), default=0),
        sa.Column('amount', sa.Numeric(15, 2), default=0),
        sa.Column('account_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['voucher_id'], ['vouchers.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['account_id'], ['accounts.id'], ),
    )
    op.create_index('idx_voucher_items_voucher', 'voucher_items', ['voucher_id'])

    # Budget Lines Table
    op.create_table('budget_lines',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('account_id', sa.Integer(), nullable=False),
        sa.Column('period_id', sa.Integer(), nullable=True),
        sa.Column('fiscal_year', sa.Integer(), nullable=False),
        sa.Column('budgeted_amount', sa.Numeric(15, 2), default=0),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('created_by_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.ForeignKeyConstraint(['account_id'], ['accounts.id'], ),
        sa.ForeignKeyConstraint(['period_id'], ['financial_periods.id'], ),
        sa.ForeignKeyConstraint(['created_by_id'], ['user.id'], ),
    )
    op.create_index('idx_budget_lines_account', 'budget_lines', ['account_id'])
    op.create_index('idx_budget_lines_year', 'budget_lines', ['fiscal_year'])


def downgrade():
    op.drop_table('budget_lines')
    op.drop_table('voucher_items')
    op.drop_table('vouchers')
    op.drop_table('journal_lines')
    op.drop_table('journal_entries')
    op.drop_table('financial_periods')
    op.drop_table('accounts')
    op.drop_table('account_categories')
