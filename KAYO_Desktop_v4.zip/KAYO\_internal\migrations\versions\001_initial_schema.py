"""Initial database schema

Revision ID: 001_initial
Revises: 
Create Date: 2025-12-12

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '001_initial'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    # Create roles table first (referenced by users)
    op.create_table('roles',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=50), nullable=False),
        sa.Column('description', sa.String(length=200), nullable=True),
        sa.Column('permissions', sa.Text(), nullable=True),
        sa.Column('is_system', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name')
    )

    # Create events table (referenced by users and delegates)
    op.create_table('events',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=200), nullable=False),
        sa.Column('slug', sa.String(length=100), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('start_date', sa.Date(), nullable=False),
        sa.Column('end_date', sa.Date(), nullable=False),
        sa.Column('registration_deadline', sa.DateTime(), nullable=True),
        sa.Column('venue', sa.String(length=200), nullable=True),
        sa.Column('venue_address', sa.Text(), nullable=True),
        sa.Column('logo_url', sa.String(length=500), nullable=True),
        sa.Column('primary_color', sa.String(length=7), nullable=True),
        sa.Column('secondary_color', sa.String(length=7), nullable=True),
        sa.Column('max_delegates', sa.Integer(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('is_published', sa.Boolean(), nullable=True),
        sa.Column('custom_fields', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('updated_at', sa.DateTime(), nullable=True),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('slug')
    )

    # Create users table
    op.create_table('users',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('email', sa.String(length=120), nullable=False),
        sa.Column('phone', sa.String(length=15), nullable=True),
        sa.Column('role', sa.String(length=20), nullable=False),
        sa.Column('role_id', sa.Integer(), nullable=True),
        sa.Column('password_hash', sa.String(length=256), nullable=True),
        sa.Column('local_church', sa.String(length=100), nullable=True),
        sa.Column('parish', sa.String(length=100), nullable=True),
        sa.Column('archdeaconry', sa.String(length=100), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('last_login', sa.DateTime(), nullable=True),
        sa.Column('session_token', sa.String(length=64), nullable=True),
        sa.Column('google_id', sa.String(length=100), nullable=True),
        sa.Column('profile_picture', sa.String(length=500), nullable=True),
        sa.Column('oauth_provider', sa.String(length=20), nullable=True),
        sa.Column('current_event_id', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['current_event_id'], ['events.id'], ),
        sa.ForeignKeyConstraint(['role_id'], ['roles.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('email'),
        sa.UniqueConstraint('google_id'),
        sa.UniqueConstraint('phone')
    )

    # Create pricing_tiers table
    op.create_table('pricing_tiers',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('event_id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('description', sa.String(length=200), nullable=True),
        sa.Column('price', sa.Float(), nullable=False),
        sa.Column('valid_from', sa.DateTime(), nullable=True),
        sa.Column('valid_until', sa.DateTime(), nullable=True),
        sa.Column('max_delegates', sa.Integer(), nullable=True),
        sa.Column('group_min_size', sa.Integer(), nullable=True),
        sa.Column('group_discount_percent', sa.Float(), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Create payments table
    op.create_table('payments',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('amount', sa.Float(), nullable=False),
        sa.Column('payment_mode', sa.String(length=50), nullable=True),
        sa.Column('transaction_id', sa.String(length=50), nullable=True),
        sa.Column('mpesa_receipt_number', sa.String(length=50), nullable=True),
        sa.Column('checkout_request_id', sa.String(length=100), nullable=True),
        sa.Column('merchant_request_id', sa.String(length=100), nullable=True),
        sa.Column('phone_number', sa.String(length=15), nullable=True),
        sa.Column('status', sa.String(length=20), nullable=True),
        sa.Column('result_code', sa.String(length=10), nullable=True),
        sa.Column('result_desc', sa.String(length=200), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.Column('completed_at', sa.DateTime(), nullable=True),
        sa.Column('delegates_count', sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('transaction_id')
    )

    # Create delegates table
    op.create_table('delegates',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('ticket_number', sa.String(length=20), nullable=False),
        sa.Column('delegate_number', sa.Integer(), nullable=True),
        sa.Column('name', sa.String(length=100), nullable=False),
        sa.Column('local_church', sa.String(length=100), nullable=False),
        sa.Column('parish', sa.String(length=100), nullable=False),
        sa.Column('archdeaconry', sa.String(length=100), nullable=False),
        sa.Column('phone_number', sa.String(length=15), nullable=True),
        sa.Column('id_number', sa.String(length=20), nullable=True),
        sa.Column('gender', sa.String(length=10), nullable=False),
        sa.Column('category', sa.String(length=20), nullable=True),
        sa.Column('event_id', sa.Integer(), nullable=True),
        sa.Column('pricing_tier_id', sa.Integer(), nullable=True),
        sa.Column('custom_field_values', sa.Text(), nullable=True),
        sa.Column('registered_by', sa.Integer(), nullable=False),
        sa.Column('registered_at', sa.DateTime(), nullable=True),
        sa.Column('is_paid', sa.Boolean(), nullable=True),
        sa.Column('payment_id', sa.Integer(), nullable=True),
        sa.Column('amount_paid', sa.Float(), nullable=True),
        sa.Column('payment_confirmed_by', sa.Integer(), nullable=True),
        sa.Column('payment_confirmed_at', sa.DateTime(), nullable=True),
        sa.Column('checked_in', sa.Boolean(), nullable=True),
        sa.Column('checked_in_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.ForeignKeyConstraint(['payment_confirmed_by'], ['users.id'], ),
        sa.ForeignKeyConstraint(['payment_id'], ['payments.id'], ),
        sa.ForeignKeyConstraint(['pricing_tier_id'], ['pricing_tiers.id'], ),
        sa.ForeignKeyConstraint(['registered_by'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('ticket_number')
    )

    # Create check_in_records table
    op.create_table('check_in_records',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('delegate_id', sa.Integer(), nullable=False),
        sa.Column('event_id', sa.Integer(), nullable=False),
        sa.Column('check_in_date', sa.Date(), nullable=False),
        sa.Column('check_in_time', sa.DateTime(), nullable=True),
        sa.Column('checked_in_by', sa.Integer(), nullable=True),
        sa.Column('session_name', sa.String(length=100), nullable=True),
        sa.Column('check_in_method', sa.String(length=20), nullable=True),
        sa.ForeignKeyConstraint(['checked_in_by'], ['users.id'], ),
        sa.ForeignKeyConstraint(['delegate_id'], ['delegates.id'], ),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Create announcements table
    op.create_table('announcements',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('event_id', sa.Integer(), nullable=True),
        sa.Column('title', sa.String(length=200), nullable=False),
        sa.Column('content', sa.Text(), nullable=False),
        sa.Column('channel', sa.String(length=20), nullable=True),
        sa.Column('target_audience', sa.String(length=50), nullable=True),
        sa.Column('status', sa.String(length=20), nullable=True),
        sa.Column('scheduled_at', sa.DateTime(), nullable=True),
        sa.Column('sent_at', sa.DateTime(), nullable=True),
        sa.Column('recipients_count', sa.Integer(), nullable=True),
        sa.Column('created_by', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['created_by'], ['users.id'], ),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Create payment_reminders table
    op.create_table('payment_reminders',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('delegate_id', sa.Integer(), nullable=False),
        sa.Column('reminder_type', sa.String(length=20), nullable=True),
        sa.Column('channel', sa.String(length=20), nullable=True),
        sa.Column('message', sa.Text(), nullable=True),
        sa.Column('status', sa.String(length=20), nullable=True),
        sa.Column('sent_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['delegate_id'], ['delegates.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Create payment_discrepancies table
    op.create_table('payment_discrepancies',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('payment_id', sa.Integer(), nullable=True),
        sa.Column('delegate_id', sa.Integer(), nullable=True),
        sa.Column('discrepancy_type', sa.String(length=50), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('expected_amount', sa.Float(), nullable=True),
        sa.Column('actual_amount', sa.Float(), nullable=True),
        sa.Column('status', sa.String(length=20), nullable=True),
        sa.Column('resolution', sa.Text(), nullable=True),
        sa.Column('resolved_by', sa.Integer(), nullable=True),
        sa.Column('resolved_at', sa.DateTime(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['delegate_id'], ['delegates.id'], ),
        sa.ForeignKeyConstraint(['payment_id'], ['payments.id'], ),
        sa.ForeignKeyConstraint(['resolved_by'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Create audit_logs table
    op.create_table('audit_logs',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=True),
        sa.Column('action', sa.String(length=50), nullable=False),
        sa.Column('resource_type', sa.String(length=50), nullable=False),
        sa.Column('resource_id', sa.Integer(), nullable=True),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('old_values', sa.Text(), nullable=True),
        sa.Column('new_values', sa.Text(), nullable=True),
        sa.Column('ip_address', sa.String(length=50), nullable=True),
        sa.Column('user_agent', sa.String(length=500), nullable=True),
        sa.Column('event_id', sa.Integer(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
        sa.PrimaryKeyConstraint('id')
    )


def downgrade():
    op.drop_table('audit_logs')
    op.drop_table('payment_discrepancies')
    op.drop_table('payment_reminders')
    op.drop_table('announcements')
    op.drop_table('check_in_records')
    op.drop_table('delegates')
    op.drop_table('payments')
    op.drop_table('pricing_tiers')
    op.drop_table('users')
    op.drop_table('events')
    op.drop_table('roles')
