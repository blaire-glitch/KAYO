"""Add payment_method and mpesa_reference columns to fund_transfers table

Revision ID: 003
Revises: 002
Create Date: 2025-01-15
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '003'
down_revision = '002'
branch_labels = None
depends_on = None


def upgrade():
    # Add payment_method and mpesa_reference columns to fund_transfers table
    op.add_column('fund_transfers', sa.Column('payment_method', sa.String(length=50), nullable=True, server_default='cash'))
    op.add_column('fund_transfers', sa.Column('mpesa_reference', sa.String(length=100), nullable=True))


def downgrade():
    op.drop_column('fund_transfers', 'mpesa_reference')
    op.drop_column('fund_transfers', 'payment_method')
